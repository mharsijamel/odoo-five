# -*- coding: utf-8 -*-
{
    'name': "Custom Sequence for Partner ref",

    'summary': """add Custom Sequence for Partner ref
       """,
    'description': """
       add Custom Sequence for Partner ref
    """,
    'author': "jamel mharsi",
    'website': "http://webvue.tn",
    'category': 'account',
    'depends': ['base'],
    'version': '1.0.0',
    'data': [
        'data/sequence_data.xml',
    ],
    'installable': True,
    'auto_install': False,
}
